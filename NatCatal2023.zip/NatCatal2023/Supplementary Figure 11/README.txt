C2H4 reaction orders and H2 reaction orders in Supplementary Figure 11 (a) and (b) are calculated by applying C2H4 and H2 adsorption energy correction
at 318K to other experimental temperatures

C2H4 reaction orders and H2 reaction orders in Supplementary Figure 11 (c) and (d) are calculated by applying C2H4 and H2 adsorption energy correction
at each experimental temperature, using the genetic algorithm presented in Supplementary Figure 10