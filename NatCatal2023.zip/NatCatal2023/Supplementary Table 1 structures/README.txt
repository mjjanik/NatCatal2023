R42-R56 structures are not provided. The energetics are treated the same with R24-R38. Because the energetics difference is negligible, as demonstrated in
Supplementary Information.